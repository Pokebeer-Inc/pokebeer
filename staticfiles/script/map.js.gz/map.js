document.addEventListener("DOMContentLoaded", function() {
    let movingMarker = null;
    let mapInstance = null;
    let isMovingMode = false;
    
    // 1. Initialisation de la carte
    const map = L.map('map', {zoomControl: false}).setView([46.603354, 1.888334], 5);
    L.control.zoom({ position: 'bottomleft' }).addTo(map);
    L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap France'
    }).addTo(map);

    new ResizeObserver(() => {
        map.invalidateSize();
    }).observe(document.getElementById('map'));

    mapInstance = map;

    // Repères aux couleurs du thème (scripts/pins.js) ; chaque famille a sa couche, que les puces du haut affichent ou masquent
    const layers = { bar: L.layerGroup().addTo(map), brewery: L.layerGroup().addTo(map), spot: L.layerGroup().addTo(map) };

    // 2. Extraction des données préparées par Django dans le HTML caché
    const spotsContainer = document.getElementById('spots-data-container');
    const spotsData = {};
    const mapBounds = [];

    if (spotsContainer) {
        document.querySelectorAll('.spot-data-item').forEach(item => {
            const slug = item.dataset.slug;
            const lat = parseFloat(item.dataset.lat);
            const lng = parseFloat(item.dataset.lng);
            // On récupère le design HTML du popup déjà formaté par Django
            const popupHtml = item.querySelector('.popup-template').innerHTML;
            
            spotsData[slug] = {
                slug: slug,
                title: item.dataset.title,
                description: item.dataset.desc,
                date: item.dataset.dateVal,
                lat: lat,
                lng: lng,
                is_owner: item.dataset.isOwner === 'true',
                // Nettoyage des chaînes "slug1,slug2," en vrais tableaux JavaScript
                drink_slugs: item.dataset.drinkSlugs.split(',').filter(Boolean),
                other_beer_slugs: item.dataset.otherBeerSlugs.split(',').filter(Boolean),
                friend_usernames: item.dataset.friendUsernames.split(',').filter(Boolean)
            };

            // Ajout direct du marqueur sur la carte
            const marker = L.marker([lat, lng], {icon: PokebeerPins.spot(), title: item.dataset.title}).addTo(layers.spot);
            marker.bindPopup(popupHtml);
            mapBounds.push([lat, lng]);
        });
    }

    // Chargement des Bars et Brasseries
    const placesContainer = document.getElementById('places-data-container');
    const placeMarkers = {}; // « bar:slug » / « brewery:slug » -> marqueur, pour ouvrir un établissement depuis la recherche
    if (placesContainer) {
        document.querySelectorAll('.place-data-item').forEach(item => {
            const lat = parseFloat(item.dataset.lat);
            const lng = parseFloat(item.dataset.lng);
            const type = item.dataset.type;
            const url = item.dataset.url;
            const name = item.dataset.name;

            const marker = L.marker([lat, lng], {icon: PokebeerPins.forPlace(type), title: name}).addTo(type === 'bar' ? layers.bar : layers.brewery);
            placeMarkers[type + ':' + item.dataset.slug] = marker;
            mapBounds.push([lat, lng]);
            
            // Événement au clic : Ouverture de la modale et chargement du contenu
            marker.on('click', function() {
                const modal = document.getElementById('modal_place');
                const contentDiv = document.getElementById('modal_place_content');
                
                // Affiche le loader
                contentDiv.innerHTML = '<div class="flex justify-center p-20"><span class="loading loading-spinner loading-lg"></span></div>';
                modal.showModal();

                // Aspire la page ciblée
                fetch(url)
                    .then(response => response.text())
                    .then(html => {
                        // Transforme le texte HTML en vrai document parcourable
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        
                        // Extrait UNIQUEMENT le contenu utile (le block content) pour éviter les doublons de navbar
                        const extractedContent = doc.querySelector('.p-4.flex-1.mb-16');
                        
                        if (extractedContent) {
                            contentDiv.innerHTML = extractedContent.innerHTML;
                            
                            // UX 1 : Cache le bouton "Retour" natif de la page aspirée puisqu'on a déjà la croix de la modale
                            const backBtn = contentDiv.querySelector('a[href="javascript:history.back()"]');
                            if (backBtn) backBtn.style.display = 'none';

                            // UX 2 : Supprime la mini-carte pour éviter une redondance sur la page map
                            const miniMap = contentDiv.querySelector('#place-map');
                            if (miniMap) miniMap.parentElement.remove();
                            
                        } else {
                            contentDiv.innerHTML = '<p class="text-center p-10 text-error">Erreur lors du chargement des données.</p>';
                        }
                    })
                    .catch(err => {
                        console.error('Erreur Fetch:', err);
                        contentDiv.innerHTML = '<p class="text-center p-10 text-error">Impossible de joindre le serveur.</p>';
                    });
            });
        });
    }

    // Centrage automatique sur tous les points
    if (mapBounds.length > 0) {
        map.fitBounds(mapBounds, { maxZoom: 5, padding: [30, 30] }); 
    }

    // Arrivée depuis la recherche (?kind=bar&place=slug) : centre la carte et ouvre la fiche. Les paramètres ne servent qu'à
    // retrouver un marqueur déjà présent (clé de dictionnaire) : ils ne sont jamais insérés dans la page.
    const requested = new URLSearchParams(window.location.search);
    const requestedMarker = placeMarkers[requested.get('kind') + ':' + requested.get('place')];
    if (requestedMarker) {
        map.setView(requestedMarker.getLatLng(), 16);
        requestedMarker.fire('click');
    }

    // Gestion de l'ouverture de la modale d'édition
    window.openEditModal = function(spotSlug) {
        const data = spotsData[spotSlug];
        if (!data) return;

        document.getElementById('modal-title').innerText = "Modifier le lieu";
        document.getElementById('spot-slug').value = data.slug;
        document.getElementById('spot-title').value = data.title;
        document.getElementById('spot-desc').value = data.description;
        document.getElementById('spot-date').value = data.date;
        document.getElementById('spot-lat').value = data.lat;
        document.getElementById('spot-lng').value = data.lng;

        // Gestion de l'affichage des bières
        document.querySelectorAll('.drink-item').forEach(item => {
            const isDeleted = item.getAttribute('data-is-deleted') === 'true';
            const drinkSlug = item.getAttribute('data-drink-slug');
            
            item.style.display = (!isDeleted || data.drink_slugs.includes(drinkSlug)) ? 'flex' : 'none';
        });

        // Gestion du cochage / grisage des bières
        document.querySelectorAll('.drink-checkbox').forEach(cb => {
            const beerSlug = cb.getAttribute('data-beer-slug');
            cb.checked = data.drink_slugs.includes(cb.value);
            
            if (data.other_beer_slugs.includes(beerSlug)) {
                cb.disabled = true;
                cb.parentElement.classList.add('opacity-50', 'cursor-not-allowed');
            } else {
                cb.disabled = false;
                cb.parentElement.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        });

        // Gestion des droits (créateur)
        const friendsSection = document.getElementById('friends-section');
        const deleteForm = document.getElementById('form-delete-spot');
        
        if (data.is_owner) {
            friendsSection.style.display = 'block';
            document.querySelectorAll('.friend-checkbox').forEach(cb => {
                cb.checked = data.friend_usernames.includes(cb.value);
            });
            deleteForm.action = `/delete-spot/${spotSlug}/`;
            deleteForm.style.display = "block";
        } else {
            friendsSection.style.display = 'none';
            deleteForm.style.display = "none";
        }

        document.getElementById('modal_add_spot').showModal();
    };

    // 4. Création d'un NOUVEAU point : clic sur la carte, ou bouton « Ajouter une dégustation ici » d'un résultat de recherche
    function openNewSpotModal(latlng, title) {
        document.getElementById('modal-title').innerText = "Ajouter un lieu";
        document.getElementById('spot-slug').value = ""; 
        document.getElementById('spot-title').value = title || "";
        document.getElementById('spot-desc').value = "";
        
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('spot-date').value = today;
        
        document.getElementById('spot-lat').value = latlng.lat.toFixed(6);
        document.getElementById('spot-lng').value = latlng.lng.toFixed(6);

        // Remise à zéro des champs
        document.querySelectorAll('.friend-checkbox').forEach(cb => cb.checked = false);
        document.querySelectorAll('.drink-checkbox').forEach(cb => {
            cb.checked = false;
            cb.disabled = false;
            cb.parentElement.classList.remove('opacity-50', 'cursor-not-allowed');
        });
        document.querySelectorAll('.drink-item').forEach(item => {
            item.style.display = item.getAttribute('data-is-deleted') === 'true' ? 'none' : 'flex';
        });
        
        document.getElementById('form-delete-spot').style.display = 'none';
        document.getElementById('friends-section').style.display = 'block';

        document.getElementById('modal_add_spot').showModal();
    }

    map.on('click', function(e) {
        if (isMovingMode) return;
        openNewSpotModal(e.latlng);
    });

    // 5. Gestion de la géolocalisation
    let userMarker = null;
    let geoWatchId = null;

    const userIcon = PokebeerPins.user();

    const geolocBtn = document.getElementById('geoloc-btn');
    if (geolocBtn) {
        geolocBtn.addEventListener('click', function() {
            if(navigator.geolocation) {
                const originalHtml = this.innerHTML;
                
                // Si la localisation est déjà active, on se contente de recentrer la carte
                if (geoWatchId !== null && userMarker) {
                    map.setView(userMarker.getLatLng(), 16);
                    return;
                }

                // On affiche le loader
                this.innerHTML = '<span class="loading loading-spinner loading-xs"></span>';
                
                // watchPosition suit l'utilisateur en temps réel
                geoWatchId = navigator.geolocation.watchPosition((position) => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    // Restaure le bouton et centre la carte uniquement lors du tout premier fix
                    if (this.innerHTML !== originalHtml) {
                        this.innerHTML = originalHtml;
                        map.setView([lat, lng], 16);
                    }

                    // Crée le marqueur "bonhomme" s'il n'existe pas, ou déplace-le s'il existe déjà
                    if (!userMarker) {
                        userMarker = L.marker([lat, lng], {
                            icon: userIcon, 
                            zIndexOffset: 9999 // S'assure qu'il passe au-dessus des autres points
                        }).addTo(map);
                        userMarker.bindPopup("<div class='text-center font-bold mb-0'>Vous êtes ici</div>");
                    } else {
                        userMarker.setLatLng([lat, lng]);
                    }
                }, (error) => {
                    console.error("Erreur de géolocalisation:", error);
                    this.innerHTML = originalHtml;
                }, {
                    enableHighAccuracy: true,
                    maximumAge: 0,
                    timeout: 20000
                });
            }
        });
    }

    // --- Fonctions globales (Accessibles par les boutons HTML de la modale) ---
    
    window.updateToCurrentLocation = function() {
        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const latInput = document.getElementById('spot-lat');
                const lngInput = document.getElementById('spot-lng');
                latInput.value = position.coords.latitude.toFixed(6);
                lngInput.value = position.coords.longitude.toFixed(6);
                
                // Effet visuel
                latInput.classList.add('bg-success/20');
                setTimeout(() => latInput.classList.remove('bg-success/20'), 1000);
            });
        }
    };

    window.startMoveMode = function() {
        isMovingMode = true;
        const lat = parseFloat(document.getElementById('spot-lat').value);
        const lng = parseFloat(document.getElementById('spot-lng').value);

        document.getElementById('modal_add_spot').close();
        document.getElementById('move-overlay').classList.remove('-translate-y-full');

        mapInstance.setView([lat, lng], 17);

        movingMarker = L.marker([lat, lng], {
            icon: PokebeerPins.spot(),
            draggable: true,
            zIndexOffset: 1000
        }).addTo(mapInstance);

        movingMarker.bindTooltip("Faites-moi glisser !", {permanent: true, direction: 'top', offset: [0,-34]}).openTooltip();
    };

    window.finishMoveMode = function() {
        if (movingMarker) {
            const newPos = movingMarker.getLatLng();
            document.getElementById('spot-lat').value = newPos.lat.toFixed(6);
            document.getElementById('spot-lng').value = newPos.lng.toFixed(6);
            
            cleanupMoveMode();
            document.getElementById('modal_add_spot').showModal();
        }
    };

    window.cancelMoveMode = function() {
        cleanupMoveMode();
        document.getElementById('modal_add_spot').showModal();
    };

    function cleanupMoveMode() {
        isMovingMode = false;
        if (movingMarker) {
            mapInstance.removeLayer(movingMarker);
            movingMarker = null;
        }
        document.getElementById('move-overlay').classList.add('-translate-y-full');
    }

    // Puces du haut : affichent ou masquent les bars, les brasseries et les souvenirs
    document.querySelectorAll('[data-layer]').forEach(chip => {
        chip.addEventListener('click', () => {
            const layer = layers[chip.dataset.layer];
            const visible = map.hasLayer(layer);
            if (visible) map.removeLayer(layer); else map.addLayer(layer);
            chip.classList.toggle('is-on', !visible);
            chip.setAttribute('aria-pressed', String(!visible));
        });
    });

    // --- MOTEUR DE RECHERCHE DE LIEUX (Nominatim) ---
    let searchMarker = null;
    let searchTitle = '';

    window.searchLocation = async function() {
        const query = document.getElementById('map-search-input').value.trim();
        const resultsContainer = document.getElementById('map-search-results');
        
        // Empêche les requêtes inutiles pour 1 ou 2 lettres
        if (query.length < 3) {
            resultsContainer.classList.add('hidden');
            return;
        }

        // Affichage du loader pendant la recherche
        resultsContainer.innerHTML = '<li class="p-2 flex justify-center"><span class="loading loading-spinner loading-sm"></span></li>';
        resultsContainer.classList.remove('hidden');

        try {
            // Appel à l'API gratuite OpenStreetMap
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=8`);
            const data = await response.json();

            resultsContainer.innerHTML = ''; // On vide le loader

            // Gestion d'aucun résultat
            if (data.length === 0) {
                resultsContainer.innerHTML = '<li class="p-2 text-center text-xs text-gray-500 italic">Aucun résultat trouvé</li>';
                return;
            }

            // Construction de la liste des résultats
            data.forEach(place => {
                const li = document.createElement('li');
                li.setAttribute('role', 'option');
                li.innerHTML = `<a class="text-sm py-2 border-b border-base-300 last:border-none cursor-pointer block w-full hover:bg-primary/30 font-medium">
                                    <span class="truncate block w-full"></span>
                                </a>`;
                // Texte renvoyé par un service tiers : jamais interprété comme du HTML
                li.querySelector('span').textContent = place.display_name;
                
                // Action au clic : focus sur la carte
                li.onclick = () => {
                    if (mapInstance) {
                        mapInstance.setView([place.lat, place.lon], 16);
                        
                        if (searchMarker) {
                            mapInstance.removeLayer(searchMarker);
                        }
                        
                        searchTitle = place.display_name.split(',')[0].trim().slice(0, 150);
                        searchMarker = L.marker([place.lat, place.lon], {icon: PokebeerPins.search()}).addTo(mapInstance);
                        
                        // Le bouton lit la position du repère de recherche : aucune valeur du service tiers n'est copiée dans un attribut
                        const popupContent = `
                            <div class="flex flex-col gap-2 max-w-[220px]">
                                <span class="text-sm font-bold leading-tight">${escapeHtml(place.display_name)}</span>
                                <button type="button" onclick="addSpotAtSearchResult()" class="btn btn-sm btn-primary border-secondary text-black normal-case w-full mt-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                                    Ajouter une dégustation ici
                                </button>
                                <button type="button" onclick="clearSearchMarker()" class="btn btn-xs btn-outline border-error text-error flex gap-1 w-full">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
                                    Effacer
                                </button>
                            </div>
                        `;
                        searchMarker.bindPopup(popupContent).openPopup();
                    }
                    
                    resultsContainer.classList.add('hidden');
                    document.getElementById('map-search-input').value = place.display_name.split(',')[0];
                };
                resultsContainer.appendChild(li);
            });
        } catch (error) {
            console.error("Erreur de géocodage :", error);
            resultsContainer.innerHTML = '<li class="p-2 text-center text-xs text-error">Erreur de connexion</li>';
        }
    };

    // Depuis la bulle d'un résultat : ouvre la fenêtre d'ajout, positionnée sur le résultat et nommée d'après lui
    window.addSpotAtSearchResult = function() {
        if (!searchMarker) return;
        const position = searchMarker.getLatLng();
        searchMarker.closePopup();
        openNewSpotModal(position, searchTitle);
    };

    window.clearSearchMarker = function() {
        if (searchMarker && mapInstance) {
            mapInstance.removeLayer(searchMarker);
            searchMarker = null; // On réinitialise la variable
            searchTitle = '';
        }
        document.getElementById('map-search-input').value = ''; // On vide la barre de recherche
    };

    // UX : Fermer les résultats si on clique n'importe où ailleurs sur la carte
    map.on('click', function() {
        document.getElementById('map-search-results').classList.add('hidden');
    });
});