let pressTimer;
let currentDrinkSlug = null;
let isPressing = false; // Permet de savoir si on est en train de maintenir l'appui
let lastTapTime = 0;

// Gère le double-tap et double-clic
function handleDoubleTap(e, drinkSlug) {
    const currentTime = new Date().getTime();
    const tapLength = currentTime - lastTapTime;
    
    // Si le temps entre 2 clics est très court (moins de 400ms)
    if (tapLength < 400 && tapLength > 0) {
        react(e, drinkSlug, true); // Force un Like
        e.preventDefault(); // Empêche le zoom par défaut du navigateur sur mobile
    }
    lastTapTime = currentTime;
}

// Démarre le chronomètre au toucher/clic long
function startPress(e, drinkSlug) {
    if (e.type === 'mousedown' && e.button !== 0) return; // Ignore clic droit
    
    isPressing = true;
    pressTimer = setTimeout(() => {
        if (isPressing) { // Vérifie qu'on est toujours en train d'appuyer
            showReactions(drinkSlug);
            // Petit retour haptique sur mobile pour indiquer que le menu s'ouvre
            if (window.navigator && window.navigator.vibrate) window.navigator.vibrate(50);
        }
    }, 500); // 500ms d'appui
}

// Annule si l'utilisateur relâche trop tôt
function cancelPress() {
    isPressing = false;
    clearTimeout(pressTimer);
}

// Affiche le menu des pouces
function showReactions(drinkSlug) {
    hideAllReactions();
    const menu = document.getElementById('reactions-' + drinkSlug);
    if (menu) {
        menu.classList.remove('hidden', 'scale-0');
        menu.classList.add('scale-100');
        currentDrinkSlug = drinkSlug;
    }
}

// Cache les menus
function hideAllReactions() {
    document.querySelectorAll('.reaction-menu').forEach(menu => {
        menu.classList.remove('scale-100');
        menu.classList.add('hidden', 'scale-0');
    });
    currentDrinkSlug = null;
}

// Cache le menu si on clique n'importe où ailleurs (SAUF sur le menu lui-même)
document.addEventListener('pointerdown', (e) => { // pointerdown est plus fiable que click sur mobile/desktop
    if (currentDrinkSlug && !e.target.closest('.reaction-menu') && !e.target.closest('.drink-card')) {
        hideAllReactions();
    }
});

// Envoi de la réaction (Like/Dislike) au serveur
function react(event, drinkSlug, isLike) {
    event.preventDefault(); // Empêche les comportements par défaut (comme le double clic sur mobile)
    event.stopPropagation(); // Évite que le pointerdown global ou d'autres clics soient déclenchés
    
    hideAllReactions();
    
    fetch(`/drink/${drinkSlug}/react/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]') ? document.querySelector('[name=csrfmiddlewaretoken]').value : window.CSRF_TOKEN
        },
        body: JSON.stringify({ is_like: isLike })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Met à jour le Score Global
            const scoreSpan = document.getElementById('score-val-' + drinkSlug);
            scoreSpan.innerText = data.score > 0 ? '+' + data.score : data.score;
            
            scoreSpan.classList.remove('text-success', 'text-error', 'text-gray-300', 'opacity-50');
            if (data.score > 0) scoreSpan.classList.add('text-success');
            else if (data.score < 0) scoreSpan.classList.add('text-error');
            else {
                scoreSpan.classList.add('text-gray-300', 'opacity-50');
                scoreSpan.innerText = "0"; 
            }

            // Met à jour les petits compteurs en bas à droite
            document.getElementById('likes-count-' + drinkSlug).innerText = data.likes;
            document.getElementById('dislikes-count-' + drinkSlug).innerText = data.dislikes;

            // Met à jour les couleurs des petits pouces en bas à droite
            const thumbUp = document.getElementById('thumb-up-' + drinkSlug);
            const thumbDown = document.getElementById('thumb-down-' + drinkSlug);
            
            thumbUp.classList.remove('text-success');
            thumbDown.classList.remove('text-error');
            
            if (data.current_reaction === true) {
                thumbUp.classList.add('text-success'); // Colore le pouce en haut en vert
            } else if (data.current_reaction === false) {
                thumbDown.classList.add('text-error'); // Colore le pouce en bas en rouge
            }

            // ---------------------------------------------------------
            // LOGIQUE DE TRI DYNAMIQUE
            // ---------------------------------------------------------
            
            // Mettre à jour la valeur data-score de la carte
            const card = document.getElementById('drink-card-' + drinkSlug);
            if (card) {
                card.dataset.score = data.score;
            }

            const container = document.getElementById('reviews-container');
            if (container) {
                const cards = Array.from(container.querySelectorAll('.drink-card'));
                
                // Sauvegarder la position de chaque carte AVANT le tri
                const firstPositions = new Map();
                cards.forEach(c => {
                    firstPositions.set(c.id, c.getBoundingClientRect());
                });
                
                // Trier le tableau de cartes
                cards.sort((a, b) => {
                    const scoreA = parseInt(a.dataset.score) || 0;
                    const scoreB = parseInt(b.dataset.score) || 0;
                    return scoreB - scoreA; // Tri décroissant
                });
                
                // Mettre à jour le DOM (les cartes "sautent" à leur nouvelle position)
                cards.forEach(c => container.appendChild(c));

                // LAST, INVERT, PLAY : Animer le déplacement
                cards.forEach(c => {
                    const first = firstPositions.get(c.id);
                    const last = c.getBoundingClientRect(); // Position APRÈS le tri
                    
                    const deltaX = first.left - last.left;
                    const deltaY = first.top - last.top;
                    
                    // Si la carte a bougé
                    if (deltaX !== 0 || deltaY !== 0) {
                        // INVERT : On repousse instantanément la carte à son ancienne position (sans transition)
                        c.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
                        c.style.transition = 'transform 0s';
                        
                        // PLAY : On force le navigateur à appliquer le style, puis on anime vers la position 0
                        requestAnimationFrame(() => {
                            c.offsetTop; // Force le reflow (nécessaire pour que l'animation démarre)
                            c.style.transition = 'transform 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
                            c.style.transform = '';
                        });
                    }
                });
            }

        } else {
            alert(data.error);
        }
    });
}